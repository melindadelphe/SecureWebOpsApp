document.addEventListener("DOMContentLoaded", () => {
  const scanBtn = document.getElementById("scanBtn");
  const openDashboardBtn = document.getElementById("openDashboard");
  const urlInput = document.getElementById("urlInput");
  const statusText = document.getElementById("status");

  // Handle Scan button (mock scan for now)
  scanBtn.addEventListener("click", () => {
    const url = urlInput.value.trim();

    if (!url) {
      statusText.textContent = "Please enter a URL.";
      return;
    }

    statusText.textContent = "Sending scan request...";

    // Mock backend call (for 30% demo)
    setTimeout(() => {
      statusText.textContent =
        "Scan sent! View results in SecureWebOps Dashboard.";
    }, 1500);
  });

  // Handle Open SecureWebOps button
  openDashboardBtn.addEventListener("click", () => {
    chrome.tabs.create({
      url: "http://172.20.32.8/auth"
    });
  });
});
