document.addEventListener("DOMContentLoaded", () => {
  const scanBtn = document.getElementById("scanBtn");
  const openDashboardBtn = document.getElementById("openDashboard");
  const urlInput = document.getElementById("urlInput");
  const statusText = document.getElementById("status");

  // Mock scan button (for now)
  scanBtn.addEventListener("click", () => {
    const url = urlInput.value.trim();

    if (!url) {
      statusText.textContent = "Please enter a URL.";
      return;
    }

    statusText.textContent = "Sending scan request...";
    setTimeout(() => {
      statusText.textContent = "Scan sent! View results in SecureWebOps Dashboard.";
    }, 1500);
  });

  // Open SecureWebOps login page
  openDashboardBtn.addEventListener("click", () => {
    chrome.tabs.create({
      url: "https://securewebops.gannon.link"
    });
  });
});